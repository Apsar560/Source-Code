<?php

$keyId = 'rzp_test_nheWc1pb3zqmH8';
$keySecret = 'M8MAKunkMGD6ooY8fEhRjqJ6';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
//error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
