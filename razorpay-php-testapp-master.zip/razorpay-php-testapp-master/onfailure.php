<head>
<style>
	.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  
}
.card {
        margin: 0 auto; 
        float: none; 
        margin-bottom: 10px;
        height:300px;
}
</style>
</head>
<?php
require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require('config.php');
global $CFG;
//session_start();
require('razorpay-php/Razorpay.php');
global $DB,$USER,$PAGE,$OUTPUT;
$PAGE->set_heading('Payment result');

echo $OUTPUT->header();
if(isset($_GET['id'])) {

	$cid=$_GET['id'];

	if(empty($cid)) {
		
		redirect($CFG->wwwroot.'/enrol/index.php');
		
	}
}
$img = $DB->get_record_sql("SELECT * FROM `wss_files` WHERE filesize > 0  AND filearea='overviewfiles' AND contextid IN(SELECT id FROM `wss_context` 
										WHERE instanceid = $cid AND contextlevel = 50)");
$c_data = $DB->get_record_sql("SELECT * FROM wss_course WHERE id = $cid");	
			
		$contextid = $img->contextid;
		
		$component = $img->component;
		
		$filearea = $img->filearea;
		
		$filename = $img->filename;
$img_url = $CFG->wwwroot."/pluginfile.php/$contextid/$component/$filearea/$filename";

$data='';
$data.="<img src='greentick.png' class='center' width='100' height='100'>";
$data.="<p style='font-size:25px;color:green;text-align: center;'>Payment completed successfully!</p>";
//$data.=" <p style='text-align: center;'>Payment ID: {$_POST['razorpay_payment_id']}</p>";
$data .= "   <div class='center'>
							<div class='card' style='width:23rem;'>
								<div class='card-heading'>
									<img class='card-img-top subimg' style='height:120px; padding:15px' src='$img_url' alt='Card image'>
								</div>
								<div class='card-body'>	
								<h4 class='card-title'>$c_data->shortname</h4>
								<p>$c_data->fullname</p>
								<p>Duration $c_data->duration Hr</p>
									<p>Rs: ₹$c_data->amount</p>
								</div>
								</div>
								</div>
								";





$data .="<div style='text-align:center'>  
			<a class='btn btn-primary  ' style='color:white; width:250px;' href='$CFG->wwwroot/enrol/index.php?id=$cid'>Continue</a>
			</div>";
echo $data;

echo "<script>
$('#page-navbar-con').remove();
</script>";
?>

<?php
echo $OUTPUT->footer();
?>
