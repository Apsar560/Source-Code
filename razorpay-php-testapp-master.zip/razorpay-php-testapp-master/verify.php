<?php
require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/lib/moodlelib.php');
require('config.php');
global $CFG;
//session_start();
require('razorpay-php/Razorpay.php');
global $DB,$USER,$PAGE,$OUTPUT,$USER;
$PAGE->set_heading('Payment');
?>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

<head>
<style>
	.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  
}
.card {
        margin: 0 auto; 
        float: none; 
        margin-bottom: 10px;
        height:300px;
}


  body
    {
        background:#f2f2f2;
    }

    .payment
	{
		border:1px solid #f2f2f2;
		height:280px;
        border-radius:20px;
        background:#fff;
	}
   .payment_header
   {
	   background:#00a48f;
	   padding:20px;
       border-radius:20px 20px 0px 0px;
	   
   }
   
   .check
   {
	   margin:0px auto;
	   width:50px;
	   height:50px;
	   border-radius:100%;
	   background:#fff;
	   text-align:center;
   }
   
   .check i
   {
	   vertical-align:middle;
	   line-height:50px;
	   font-size:30px;
   }

    .content 
    {
        text-align:center;
    }

    .content  h1
    {
        font-size:25px;
        padding-top:25px;
    }

    .content a
    {
        width:200px;
        height:35px;
        border-radius:30px;
        padding:5px 10px;
        background:#00a48f;
        transition:all ease-in-out 0.3s;
    }
    
    .content a:hover{
		color:#00a48f;
		background:white;
	}
    
	.fa-check{
		color:#00a48f;
	}
</style>
</head>

<?php

echo $OUTPUT->header();

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

$supportuser = core_user::get_support_user();

$to_email = $USER->email;	

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }

}



if ($success === true)
{
    //$html = "<p>Your payment was successful</p>
             //<p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
     
    $cid = $USER->courseid;      
    
    $update_pay = new stdClass();
	$update_pay->id = $USER->payid;
	$update_pay->courseid = $USER->courseid;
	$update_pay->userid = $USER->id;
	$update_pay->paymentid = $_POST['razorpay_payment_id'];
	$update_pay->status = 1;
	// $update_pay->timecreated = time();
	
	$razorpay = $DB->update_record("razorpay", $update_pay);
    unset($USER->payid);    
    unset($USER->courseid);    
    unset($USER->uid);    
    				
	$roleid = 5;			
	$enrolmethod = 'classicpay';			
	check_enrol($cid, $USER->id, $roleid, $enrolmethod);
	//data ='';
	//data.="<div>";
    //redirect($CFG->wwwroot."/enrol/razorpay-php-testapp-master/onsuccess.php?id=$cid");
    //redirect($CFG->wwwroot."/local/course_view.php?id=$cid","You're Successfully Enrolled");      
    //~ header("Location: http://192.168.0.75/wiseeapp/local/view.php?payid={$_POST['razorpay_payment_id']}"); 
    $img = $DB->get_record_sql("SELECT * FROM `wss_files` WHERE filesize > 0  AND filearea='overviewfiles' AND contextid IN(SELECT id FROM `wss_context` 
										WHERE instanceid = $cid AND contextlevel = 50)");
    $c_data = $DB->get_record_sql("SELECT * FROM wss_course WHERE id = $cid");	
    
    // course category name 
	$category = $DB->get_record_sql("SELECT * FROM `wss_course_categories` WHERE id = $c_data->category");
    
    $CourseCost = $DB->get_record_sql("SELECT cost FROM `wss_enrol` WHERE courseid = $cid AND enrol = 'classicpay' AND status='0' ");
    
	$contextid = $img->contextid;
	
	$component = $img->component;
	
	$filearea = $img->filearea;
	
	$filename = $img->filename;
	
	$img_url = $CFG->wwwroot."/pluginfile.php/$contextid/$component/$filearea/$filename";

$data='';
/*$data.="<div class='jumbotron text-center'><img src='greentick.png' class='center' width='100' height='100'>";
$data.="<h1 class='display-3'>Payment Successfull!</h1>";
$data.="<p style='text-align: center;'>Payment ID: {$_POST['razorpay_payment_id']}</p>";
//$data.=" <p style='text-align: center;'>Payment ID: {$_POST['razorpay_payment_id']}</p>";
$data .= "   <div class='center'>
							<div class='card' style='width:23rem;background-color:lightgrey;'>
								<div class='card-heading'>
									<img class='card-img-top subimg' style='height:120px; padding:15px' src='$img_url' alt='Card image'>
								</div>
								<div class='card-body'>	
								<h4 class='card-title'>$c_data->shortname</h4>
								<p>$c_data->fullname</p>
								<p>Duration $c_data->duration Hr</p>
									<p>Rs: ₹$CourseCost->cost</p>
								</div>
								</div>
								</div>
								";





$data .="<div style='text-align:center'>  
			<a class='btn btn-primary  ' style='color:white; width:250px;' href='$CFG->wwwroot/local/view.php'>Continue</a>
            </div></div>";*/

$data .="<div class='container'>
		   <div class='row'>
			  <div class='col-md-12 mx-auto mt-5'>
				 <div class='payment'>
					<div class='payment_header'>
					   <div class='check'><i class='fa fa-check' aria-hidden='true'></i></div>
					</div>
					<div class='content'>
					   <h1>Payment Success !</h1>
					   <h4 style='color:gray;'>$category->name / $c_data->fullname Now you're Enrolled in this Program.</h4>
					   <h4>Payment ID: {$_POST['razorpay_payment_id']}</h4>
					   <p>Your payment Rs: ₹$USER->amount.00</p>
					   <a style='color:white;' href='$CFG->wwwroot/local/view.php'>Ok</a>
					</div>
					
				 </div>
			  </div>
		   </div>
		</div>";
unset($USER->amount);
$subject = "Success Enrol Confirmation";
$message = "Success message Testing";
$headers = 'From: WiseTechSource';

email_to_user($USER, $supportuser, $subject, $message);

echo $data;

echo "<script>
$('#page-navbar-con').remove();
</script>";

         
}
else
{
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";

             
$subject = "Failure Enrol Confirmation";
$message = "Failure message Testing";
$headers = 'From: WiseTechSource';

email_to_user($USER, $supportuser, $subject, $message);

    redirect($CFG->wwwroot."/enrol/index.php?id=$cid", 5);         
}

echo $html;

echo $OUTPUT->footer();
?>
