<?php

require('../../config.php');
require('config.php');
require('razorpay-php/Razorpay.php');
// session_start();
global $DB,$USER,$PAGE,$OUTPUT;
$PAGE->set_heading('Payment');
$courseid = $_POST['courseid'];
//~ $coursenode = $PAGE->navbar->add('Courses', new moodle_url('/local/view.php'));
//~ $coursenode = $PAGE->navbar->add('Courses', new moodle_url('/local/course_preview.php?id='.$courseid));
//~ $coursenode->make_active();
echo $OUTPUT->header();

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

//
// We create an razorpay order using orders api
// Docs: https://docs.razorpay.com/docs/orders
//

$amount = $_POST['amount'];
$temp_amount = (int)$amount;
$courseid = $_POST['courseid'];
$coupon = $_POST['coupon'];
$coursename = $_POST['coursename'];
$imgurl = $_POST['imgurl'];
//~ $desc = $_POST['desc'];
$username = $_POST['username'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];

$USER->courseid = $courseid; 
$USER->uid = $USER->id; 

$lastid = $DB->get_record_sql("SELECT max(id) as id FROM `wss_razorpay`");

$orderData = [
    'receipt'         => $lastid+1,
    'amount'          => $amount * 100, // 2000 rupees in paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];

$razorpayOrder = $api->order->create($orderData);

$razorpayOrderId = $razorpayOrder['id'];

$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$displayAmount = $amount = $orderData['amount'];

if ($displayCurrency !== 'INR')
{
    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$checkout = 'manual';

if (isset($_GET['checkout']) and in_array($_GET['checkout'], ['automatic', 'manual'], true))
{
    $checkout = $_GET['checkout'];
}

$data = [
    "key"               => $keyId,
    "amount"            => $temp_amount,
    "courseid"          => $courseid,
    "name"              => $coursename,
    "description"       => $desc,
    "image"             => $imgurl,
    "prefill"           => [
    "name"              => $username,
    "email"             => $email,
    "contact"           => $mobile,
    ],
    "notes"             => [
    "address"           => "Payment for course enrolment",
    "merchant_order_id" => "$lastid->id+1",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
];

if ($displayCurrency !== 'INR')
{
    $data['display_currency']  = $displayCurrency;
    $data['display_amount']    = $displayAmount;
}

$json = json_encode($data);

$courseinfo = '';
$courseinfo .="<h3>Program Info:</h3>";
$courseinfo .="<div class='row'>
				<div class='col-md-6'>
					<img width='auto' height='200px;' src='$imgurl' alt='program image'/>
				</div>
			   </div><br/>
			   <div class='row'>
				<div class='col-md-12'>
					Program Name : $coursename
				</div>
				<div class='col-md-12'>
					Price : $temp_amount.00
				</div>
			   </div>
			  </div>
			   <br/>";
			   
echo $courseinfo;
require("checkout/{$checkout}.php");

echo "NOTE: Refund / Return Policy: The amount once paid is not refundable or cannot be returned.";

$insert_pay = new stdClass();
$insert_pay->courseid = $USER->courseid;
$insert_pay->coupon = $coupon;
$insert_pay->userid = $USER->id;
$insert_pay->status = 0;
$insert_pay->amount = $temp_amount;


$razorpay = $DB->insert_record("razorpay", $insert_pay);
$USER->payid = $razorpay;
$USER->amount = $temp_amount;
echo $OUTPUT->footer();
?>
