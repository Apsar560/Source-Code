<?php
require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->libdir.'/formslib.php');
require('config.php');
global $CFG,$USER;
//session_start();
require('razorpay-php/Razorpay.php');
global $DB,$USER,$PAGE,$OUTPUT;
$PAGE->set_heading('Payment History');
$PAGE->requires->js(new \moodle_url('/local/js/datat.js'));
echo $OUTPUT->header();
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;


require_login();


//$api = new Api($keyId, $keySecret);
if(isset($_GET['id'])) {

	$cid=$_GET['id'];

	if(empty($cid)) {
		
		redirect($CFG->wwwroot.'/enrol/index.php');
		
	}
}

$cid = $USER->id;

$courseoffermap_list = $DB->get_records_sql("SELECT * FROM `wss_razorpay` where userid=$cid");
$u_name=$DB->get_record_sql("SELECT * FROM `wss_user` where id=$cid");
$user_name=$u_name->username;

$data = '';

$data .="<table id='table' class='table table-striped table-bordered' style='width:100%'>
			<thead>
				<tr>
					<th>S.No</th>
					<th>User name</th>
					<th>coupon</th>
					<th>Course name</th>
					<th>Payment id</th>
					<th>Amount</th>
					<th>Date</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>";
	
	$i = 1;
	
	foreach($courseoffermap_list as $list) {
				
		
		$coupon = $list->coupon;
		$courseid = $list->courseid;
		
		$coursename=$DB->get_record_sql("SELECT * FROM wss_course WHERE id = $courseid");
		$course_name=$coursename->fullname. "/".$coursename->shortname;
		
		
		
		$paymentid = $list->paymentid;
		$status = $list->status;
		$date = $list->timecreated;
		$amount=$list->amount;
		//$payment = $api->payment->fetch('pay_FHAf5X6BFBzMqU');
		//$amount=$payment->amount;
		
		if($status == 1) {
			$status = 'Success';
		}else{
			$status = 'Failure';
		}
				
		$data .="<tr>
					<td>$i</td>
					<td>$user_name</td>
					<td>$coupon</td>
					<td>$course_name</td>					
					<td>$paymentid</td>
					<td>$amount</td>
					<td>$date</td>
					<td>$status</td>
					</tr>";
		
		$i++;
		
	}

$data .="</tbody></table>";

echo $data;
?>
    
 <script>  
 $(document).ready(function(){  
           
 });  
 </script> 

<?php
echo $OUTPUT->footer();
?>


