<?php
require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require('config.php');
global $CFG;
//session_start();
require('razorpay-php/Razorpay.php');
global $DB,$USER,$PAGE,$OUTPUT;
$PAGE->set_heading('Payment result');

echo $OUTPUT->header();
if(isset($_GET['id'])) {

	$cid=$_GET['id'];

	if(empty($cid)) {
		
		redirect($CFG->wwwroot.'/local/view.php');
		
	}
}

$data='';
$data.="<p style='font-size:25px;color:green;'>Payment completed successfully!</p>";
$data .="<a class='btn btn-primary ' style='color:white;' href='$CFG->wwwroot/local/course_view.php?id=$cid'>Return</a>";
echo $data;
?>
<?php
echo $OUTPUT->footer();
?>
